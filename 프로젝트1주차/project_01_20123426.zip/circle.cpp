#include "circle.h"

void circle::color(float r, float g, float b)
{
	red=r;
	green=g;
	blue=b;
}