#include "rectangle.h"

void rectangle::color(float r, float g, float b)
{
	red=r;
	green=g;
	blue=b;
}